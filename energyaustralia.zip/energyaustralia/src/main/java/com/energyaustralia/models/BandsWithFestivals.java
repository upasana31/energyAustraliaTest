package com.energyaustralia.models;

import java.util.HashSet;
import java.util.Set;

public class BandsWithFestivals {

	public BandsWithFestivals(String bandName, String festival) {
		this.bandName = bandName;
		setFestivals(festival);
	}
	private String bandName;
	private Set<String> festivals;
	
	public String getBandName() {
		return bandName;
	}
	
	public void setBandName(String bandName) {
		this.bandName = bandName;
	}
	
	public Set<String> getFestivals() {
		return festivals;
	}
	
	public void setFestivals(String festival) {
		if(this.festivals == null) {
			this.festivals = new HashSet<String>();
		}
		festivals.add(festival);
	}

}
