package com.energyaustralia.models;

import java.util.List;

public class MusicFestival {

	private String name;

	private List<Band> bands;
	
	public String getName() {
		return this.name;
	}
	
	public List<Band> getBands(){
		return this.bands;
	}

}
