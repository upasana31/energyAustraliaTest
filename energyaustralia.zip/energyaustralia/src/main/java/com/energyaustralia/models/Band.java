package com.energyaustralia.models;

public class Band {

	private String name;
	private String recordLabel;
	
	public String getName() {
		return this.name;
	}

	public String getRecordLabel() {
		return this.recordLabel;
	}
}
