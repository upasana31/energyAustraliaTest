package com.energyaustralia.models;

import java.util.List;

public class RecordLabel {

	private String recordLabel;
	private List<BandsWithFestivals> bandsWithFestivals;
	
	public void setBandsWithFestivals(List<BandsWithFestivals> bandsWithFestivals) {
		this.bandsWithFestivals = bandsWithFestivals;
	}
	
	public List<BandsWithFestivals> getBandsWithFestivals() {
		return this.bandsWithFestivals;
	}

	public void setRecordLabel(String recordLabel) {
		this.recordLabel = recordLabel;
	}
	
	public String getRecordLabel() {
		return this.recordLabel;
	}
}
