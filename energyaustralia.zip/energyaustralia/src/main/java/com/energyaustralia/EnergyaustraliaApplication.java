package com.energyaustralia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnergyaustraliaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnergyaustraliaApplication.class, args);

	}

}
