package com.energyaustralia.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.energyaustralia.models.Band;
import com.energyaustralia.models.BandsWithFestivals;
import com.energyaustralia.models.MusicFestival;

@RestController
public class EnergyaustraliaController {

	private String uri = "http://eacodingtest.digital.energyaustralia.com.au/api/v1/festivals";

	@RequestMapping(path = "/")
	public ResponseEntity<Object> getBandsWithFestivals() {
		RestTemplate restTemplate = new RestTemplate();
		List<MusicFestival> festivals = Arrays.asList(restTemplate.getForObject(uri, MusicFestival[].class));
		Map<String, Map<String, Set<String>>> mapBands = new HashMap<>();

		if (festivals != null) {
			List<BandsWithFestivals> bandsWithFestivals = new ArrayList<BandsWithFestivals>();
			Map<String, Set<String>> mapBandsWithFestivals = new HashMap<String, Set<String>>();
			Set<String> festivs = null;
			for (MusicFestival festival : festivals) {
				List<Band> bands = festival.getBands();
				String bandName = "", recordLabel = "";
				for (Band band : bands) {
					bandName = band.getName();
					recordLabel = band.getRecordLabel();
					if (mapBandsWithFestivals.containsKey(bandName)) {
						festivs = mapBandsWithFestivals.get(bandName);
					} else {
						festivs = new HashSet<>();
					}
					festivs.add(festival.getName() != null ? festival.getName() : "");
					mapBandsWithFestivals.put(bandName, festivs);
					}
				mapBands.put(recordLabel != null ? recordLabel : "", mapBandsWithFestivals);
			}

		}
		return ResponseEntity.ok(mapBands);
	}

}
